﻿using prjMVC.Models;

namespace prjMVC.Repository.Interfaces
{
    public interface IPedidoRepository
    {
        void CriarPedido(Pedido pedido);
    }
}
