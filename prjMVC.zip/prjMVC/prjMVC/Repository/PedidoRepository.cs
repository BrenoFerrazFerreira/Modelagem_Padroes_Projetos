﻿using prjMVC.Context;
using prjMVC.Models;
using prjMVC.Repository.Interfaces;

namespace prjMVC.Repository
{
    public class PedidoRepository : IPedidoRepository
    {
        private readonly AppDbContext varappDbContext;
        private readonly CarrinhoCompra varcarrinhoCompra;
        public PedidoRepository(AppDbContext appDbContext,
        CarrinhoCompra carrinhoCompra)
        {
            varappDbContext = appDbContext;
            varcarrinhoCompra = carrinhoCompra;
        }
        public void CriarPedido(Pedido pedido)
        {
            pedido.PedidoEnviado = DateTime.Now;
            varappDbContext.Pedidos.Add(pedido);
            varappDbContext.SaveChanges();
            var carrinhoCompraItens =
           varcarrinhoCompra.CarrinhoCompraItems;
            foreach (var carrinhoItem in carrinhoCompraItens)
            {
                var pedidoDetail = new PedidoDetalhe()
                {
                    Quantidade = carrinhoItem.Quantidade,
                    produtoId = carrinhoItem.produto.ProdutoId,
                    PedidoId = pedido.PedidoId,
                    Preco = carrinhoItem.produto.Preco
                };
                varappDbContext.PedidoDetalhes.Add(pedidoDetail);
            }
            varappDbContext.SaveChanges();
        }

    }
}
