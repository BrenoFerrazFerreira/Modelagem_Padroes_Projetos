﻿using Microsoft.AspNetCore.Mvc;
using prjMVC.Repository.Interfaces;
using prjMVC.Models;
using prjMVC.ViewModels;

namespace prjMVC.Controllers
{
    public class CarrinhoCompraController : Controller
    {
        private readonly IProdutoRepository varprodutoRepository;
        private readonly CarrinhoCompra varcarrinhoCompra;
        public CarrinhoCompraController(IProdutoRepository produtoRepository,
       CarrinhoCompra carrinhoCompra)
        {
            varprodutoRepository = produtoRepository;
            varcarrinhoCompra = carrinhoCompra;
        }
        public IActionResult Index()
        {
            var itens = varcarrinhoCompra.GetCarrinhoCompraItens();
            varcarrinhoCompra.CarrinhoCompraItems = itens;
            var carrinhoCompraVM = new CarrinhoCompraViewModel
            {
                CarrinhoCompra = varcarrinhoCompra,
                CarrinhoCompraTotal = varcarrinhoCompra.GetCarrinhoCompraTotal()
            };
            return View(carrinhoCompraVM);
        }
        public IActionResult AdicionarItemNoCarrinhoCompra(int produtoId)
        {
            var carroSelecionado = varprodutoRepository.Produtos
            .FirstOrDefault(p => p.ProdutoId == produtoId);
            if (carroSelecionado != null)
            {
                varcarrinhoCompra.AdicionarAoCarrinho(carroSelecionado);
            }
            return RedirectToAction("Index");
        }
        public IActionResult RemoverItemDoCarrinhoCompra(int produtoId)
        {
            var lancheSelecionado = varprodutoRepository.Produtos
            .FirstOrDefault(p => p.ProdutoId == produtoId);
            if (lancheSelecionado != null)
            {
                varcarrinhoCompra.RemoverDoCarrinho(lancheSelecionado);
            }
            return RedirectToAction("Index");
        }
    }

}
