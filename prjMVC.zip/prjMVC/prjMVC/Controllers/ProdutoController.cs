﻿using Microsoft.AspNetCore.Mvc;
using prjMVC.Repository.Interfaces;

namespace prjMVC.Controllers
{
    public class ProdutoController : Controller
    {
        private readonly IProdutoRepository vprodRepository;
        public ProdutoController(IProdutoRepository prodRepository)
        {
            vprodRepository = prodRepository;
        }
        public IActionResult List()
        {
            ViewData["Titulo"] = "Todos os carros";
            ViewData["Data"] = DateTime.Now;


            var produtos = vprodRepository.Produtos;
            var totalProdutos = produtos.Count();

            ViewBag.total = "Total de carros";
            ViewBag.totalProdutos = totalProdutos;
            return View(produtos);
        }
    }

}
