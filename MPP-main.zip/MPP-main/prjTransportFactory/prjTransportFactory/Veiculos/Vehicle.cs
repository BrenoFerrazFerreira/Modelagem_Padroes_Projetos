﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjTransportFactory.Veiculos
{
    public interface Vehicle
    {
        void StartRoute();
        void GetCargo();
    }
}
