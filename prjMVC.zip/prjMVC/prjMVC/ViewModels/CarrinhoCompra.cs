﻿namespace prjMVC.ViewModels
{
    public class CarrinhoCompraViewModel
    {
        public CarrinhoCompraViewModel carrinhoCompra { get; set; }
        public decimal CarrinhoCompraTotal { get; set; }

    }
}
