﻿using Microsoft.AspNetCore.Mvc;
using prjMVC.Models;
using prjMVC.Repository.Interfaces;

namespace prjMVC.Controllers
{
    public class PedidoController : Controller
    {
        private readonly IPedidoRepository varpedidoRepository;
        private readonly CarrinhoCompra varcarrinhoCompra;
        public PedidoController(IPedidoRepository pedidoRepository,CarrinhoCompra carrinhoCompra)
        {
            varpedidoRepository = pedidoRepository;
            varcarrinhoCompra = carrinhoCompra;
        }
        [HttpGet]
        public IActionResult Checkout()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Checkout(Pedido pedido)
        {
            int totalItensPedido = 0;
            decimal precoTotalPedido = 0.0m;
            //obtem os itens do carrinho de compra do cliente
            List<CarrinhoCompraItem> items =
           varcarrinhoCompra.GetCarrinhoCompraItens();
            varcarrinhoCompra.CarrinhoCompraItems = items;
            //verifica se existem itens de pedido
            if (varcarrinhoCompra.CarrinhoCompraItems.Count == 0)
            {
                ModelState.AddModelError("", "Seu carrinho esta vazio, que tal incluir um carro novo...");
            }
            //calcula o total de itens e o total do pedido
            foreach (var item in items)
            {
                totalItensPedido += item.Quantidade;
                precoTotalPedido += (item.produto.Preco * item.Quantidade); 
            }
            //atribui os valores obtidos ao pedido
            pedido.TotalItensPedido = totalItensPedido;
            pedido.PedidoTotal = precoTotalPedido;


            //valida os dados do pedido
            if (ModelState.IsValid)
            {
                //cria o pedido e os detalhes
                varpedidoRepository.CriarPedido(pedido);
                //define mensagens ao cliente
                ViewBag.CheckoutCompletoMensagem = "Obrigado pelo seu pedido:)";
                ViewBag.TotalPedido = varcarrinhoCompra.GetCarrinhoCompraTotal();
                //limpa o carrinho do cliente
                varcarrinhoCompra.LimparCarrinho();
                //exibe a view com dados do cliente e do pedido
                return View("~/Views/Pedido/CheckoutCompleto.cshtml", pedido);
            }
            foreach (var entry in ModelState)
            {
                foreach (var error in entry.Value.Errors)
                {
                    Console.WriteLine($"Chave: {entry.Key}, Erro: {error.ErrorMessage}");
                }
            }
            return View(pedido);
        }

    }
}
