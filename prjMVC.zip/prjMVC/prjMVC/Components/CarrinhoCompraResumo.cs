﻿using Microsoft.AspNetCore.Mvc;
using prjMVC.Models;
using prjMVC.ViewModels;

namespace prjMVC.Components
{
    public class CarrinhoCompraResumo : ViewComponent
    {
        private readonly CarrinhoCompra varcarrinhoCompra;
        public CarrinhoCompraResumo(CarrinhoCompra carrinhoCompra)
        {
            varcarrinhoCompra = carrinhoCompra;
        }
        public IViewComponentResult Invoke()
        {
            var itens = varcarrinhoCompra.GetCarrinhoCompraItens();
            // Fixo só para testar
            /*var itens = new List<CarrinhoCompraItem>()
            {
                new CarrinhoCompraItem(),
                new CarrinhoCompraItem()
            };*/

            varcarrinhoCompra.CarrinhoCompraItems = itens;
            var carrinhoCompraVM = new CarrinhoCompraViewModel
            {
                CarrinhoCompra = varcarrinhoCompra,
                CarrinhoCompraTotal = varcarrinhoCompra.GetCarrinhoCompraTotal()
            };
            return View(carrinhoCompraVM);
        }
    }

}
