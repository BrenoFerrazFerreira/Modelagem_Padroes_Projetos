﻿using Microsoft.AspNetCore.Mvc;

namespace prjMVC.Controllers
{
    public class ContatoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
