﻿using Microsoft.AspNetCore.Mvc;
using prjMVC.Repository.Interfaces;
using prjMVC.ViewModels;

namespace prjMVC.Controllers
{
    public class ProdutoController : Controller
    {
        private readonly IProdutoRepository vprodRepository;
        public ProdutoController(IProdutoRepository prodRepository)
        {
            vprodRepository = prodRepository;
        }
        public IActionResult List()
        {
            /*ViewData["Titulo"] = "Todos os carros";
            ViewData["Data"] = DateTime.Now;


            var produtos = vprodRepository.Produtos;
            var totalProdutos = produtos.Count();

            ViewBag.total = "Total de carros";
            ViewBag.totalProdutos = totalProdutos;
            return View(produtos);*/

            var produtoListViewModel = new ProdutoListViewModel();
            produtoListViewModel.Produtos = vprodRepository.Produtos;
            produtoListViewModel.CategoriaAtual = "Categoria Atual";
            return View(produtoListViewModel);
        }

        public IActionResult Details(int ProdutoId)
        {
            var vproduto = vprodRepository.Produtos.FirstOrDefault(l =>
            l.ProdutoId == ProdutoId);
            return View(vproduto);
        }
    }

}
